App de formulário em flutter + firebase

firebase init hosting

flutter build web

firebase deploy
